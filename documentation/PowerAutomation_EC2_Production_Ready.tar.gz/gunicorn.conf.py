# PowerAutomation Gunicorn 配置文件
# /home/ubuntu/powerautomation/smartinvention/powerautomation_server/gunicorn.conf.py

import multiprocessing
import os

# 服務器套接字
bind = "0.0.0.0:5000"
backlog = 2048

# 工作進程
workers = multiprocessing.cpu_count() * 2 + 1
worker_class = "sync"
worker_connections = 1000
timeout = 30
keepalive = 2

# 重啟
max_requests = 1000
max_requests_jitter = 50
preload_app = True

# 日誌
accesslog = "/var/log/powerautomation/access.log"
errorlog = "/var/log/powerautomation/error.log"
loglevel = "info"
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s"'

# 進程命名
proc_name = "powerautomation"

# 安全
limit_request_line = 4094
limit_request_fields = 100
limit_request_field_size = 8190

# SSL (如果需要)
# keyfile = "/etc/ssl/private/powerautomation.key"
# certfile = "/etc/ssl/certs/powerautomation.crt"

# 性能調優
worker_tmp_dir = "/dev/shm"
tmp_upload_dir = None

# 用戶和組
user = "ubuntu"
group = "ubuntu"

# 進程ID文件
pidfile = "/var/run/powerautomation/gunicorn.pid"

# 守護進程
daemon = False

# 環境變量
raw_env = [
    "FLASK_ENV=production",
    "PYTHONPATH=/home/ubuntu/powerautomation/smartinvention/powerautomation_server"
]

def when_ready(server):
    """服務器準備就緒時的回調"""
    server.log.info("PowerAutomation服務器已準備就緒")

def worker_int(worker):
    """工作進程中斷時的回調"""
    worker.log.info("工作進程 %s 被中斷", worker.pid)

def pre_fork(server, worker):
    """工作進程fork前的回調"""
    server.log.info("工作進程 %s 即將啟動", worker.pid)

def post_fork(server, worker):
    """工作進程fork後的回調"""
    server.log.info("工作進程 %s 已啟動", worker.pid)

def post_worker_init(worker):
    """工作進程初始化後的回調"""
    worker.log.info("工作進程 %s 初始化完成", worker.pid)

def worker_abort(worker):
    """工作進程異常終止時的回調"""
    worker.log.info("工作進程 %s 異常終止", worker.pid)

