#!/bin/bash

# PowerAutomation Nginx 配置腳本
# 設置反向代理和SSL

set -e

# 顏色定義
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 配置變量
DOMAIN="${1:-powerautomation.example.com}"
EMAIL="${2:-admin@example.com}"

# 創建Nginx配置
create_nginx_config() {
    log_info "創建Nginx配置文件..."
    
    sudo tee /etc/nginx/sites-available/powerautomation > /dev/null << EOF
# PowerAutomation Nginx 配置

# HTTP重定向到HTTPS
server {
    listen 80;
    server_name ${DOMAIN} www.${DOMAIN};
    
    # Let's Encrypt驗證
    location /.well-known/acme-challenge/ {
        root /var/www/html;
    }
    
    # 重定向到HTTPS
    location / {
        return 301 https://\$server_name\$request_uri;
    }
}

# HTTPS主配置
server {
    listen 443 ssl http2;
    server_name ${DOMAIN} www.${DOMAIN};
    
    # SSL配置
    ssl_certificate /etc/letsencrypt/live/${DOMAIN}/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/${DOMAIN}/privkey.pem;
    ssl_trusted_certificate /etc/letsencrypt/live/${DOMAIN}/chain.pem;
    
    # SSL安全配置
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    ssl_session_tickets off;
    ssl_stapling on;
    ssl_stapling_verify on;
    
    # 安全頭
    add_header Strict-Transport-Security "max-age=63072000" always;
    add_header X-Frame-Options DENY always;
    add_header X-Content-Type-Options nosniff always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    
    # 日誌配置
    access_log /var/log/nginx/powerautomation_access.log;
    error_log /var/log/nginx/powerautomation_error.log;
    
    # 客戶端配置
    client_max_body_size 100M;
    client_body_timeout 60s;
    client_header_timeout 60s;
    
    # Gzip壓縮
    gzip on;
    gzip_vary on;
    gzip_min_length 1024;
    gzip_proxied any;
    gzip_comp_level 6;
    gzip_types
        text/plain
        text/css
        text/xml
        text/javascript
        application/json
        application/javascript
        application/xml+rss
        application/atom+xml
        image/svg+xml;
    
    # API代理
    location /api/ {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
        proxy_read_timeout 300s;
        proxy_connect_timeout 75s;
        
        # CORS配置
        add_header Access-Control-Allow-Origin "*" always;
        add_header Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS" always;
        add_header Access-Control-Allow-Headers "DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization" always;
        add_header Access-Control-Expose-Headers "Content-Length,Content-Range" always;
        
        # 處理OPTIONS請求
        if (\$request_method = 'OPTIONS') {
            add_header Access-Control-Allow-Origin "*";
            add_header Access-Control-Allow-Methods "GET, POST, PUT, DELETE, OPTIONS";
            add_header Access-Control-Allow-Headers "DNT,User-Agent,X-Requested-With,If-Modified-Since,Cache-Control,Content-Type,Range,Authorization";
            add_header Access-Control-Max-Age 1728000;
            add_header Content-Type "text/plain; charset=utf-8";
            add_header Content-Length 0;
            return 204;
        }
    }
    
    # 靜態文件
    location /static/ {
        alias /home/ubuntu/powerautomation/smartinvention/ui/;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
    
    # 健康檢查
    location /health {
        proxy_pass http://127.0.0.1:5000/api/powerautomation/health;
        access_log off;
    }
    
    # 根路徑
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto \$scheme;
        proxy_cache_bypass \$http_upgrade;
    }
}

# 狀態監控
server {
    listen 127.0.0.1:8080;
    server_name localhost;
    
    location /nginx_status {
        stub_status on;
        access_log off;
        allow 127.0.0.1;
        deny all;
    }
}
EOF

    log_success "Nginx配置文件創建完成"
}

# 啟用站點
enable_site() {
    log_info "啟用PowerAutomation站點..."
    
    # 禁用默認站點
    sudo rm -f /etc/nginx/sites-enabled/default
    
    # 啟用PowerAutomation站點
    sudo ln -sf /etc/nginx/sites-available/powerautomation /etc/nginx/sites-enabled/
    
    log_success "站點啟用完成"
}

# 測試Nginx配置
test_nginx_config() {
    log_info "測試Nginx配置..."
    
    if sudo nginx -t; then
        log_success "Nginx配置測試通過"
    else
        log_error "Nginx配置測試失敗"
        exit 1
    fi
}

# 配置SSL證書
setup_ssl() {
    log_info "配置SSL證書..."
    
    # 創建webroot目錄
    sudo mkdir -p /var/www/html
    
    # 獲取SSL證書
    if [[ "$DOMAIN" != "powerautomation.example.com" ]]; then
        log_info "獲取Let's Encrypt SSL證書..."
        sudo certbot certonly \
            --webroot \
            --webroot-path=/var/www/html \
            --email "$EMAIL" \
            --agree-tos \
            --no-eff-email \
            --domains "$DOMAIN"
        
        if [[ $? -eq 0 ]]; then
            log_success "SSL證書獲取成功"
            
            # 設置自動續期
            (sudo crontab -l 2>/dev/null; echo "0 12 * * * /usr/bin/certbot renew --quiet") | sudo crontab -
            log_success "SSL證書自動續期設置完成"
        else
            log_warning "SSL證書獲取失敗，使用自簽名證書"
            create_self_signed_cert
        fi
    else
        log_warning "使用示例域名，創建自簽名證書"
        create_self_signed_cert
    fi
}

# 創建自簽名證書
create_self_signed_cert() {
    log_info "創建自簽名SSL證書..."
    
    sudo mkdir -p /etc/ssl/private
    sudo mkdir -p /etc/ssl/certs
    
    sudo openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout /etc/ssl/private/powerautomation.key \
        -out /etc/ssl/certs/powerautomation.crt \
        -subj "/C=US/ST=State/L=City/O=Organization/CN=${DOMAIN}"
    
    # 更新Nginx配置使用自簽名證書
    sudo sed -i "s|/etc/letsencrypt/live/${DOMAIN}/fullchain.pem|/etc/ssl/certs/powerautomation.crt|g" /etc/nginx/sites-available/powerautomation
    sudo sed -i "s|/etc/letsencrypt/live/${DOMAIN}/privkey.pem|/etc/ssl/private/powerautomation.key|g" /etc/nginx/sites-available/powerautomation
    sudo sed -i "s|ssl_trusted_certificate.*|# ssl_trusted_certificate disabled for self-signed cert|g" /etc/nginx/sites-available/powerautomation
    
    log_success "自簽名SSL證書創建完成"
}

# 主函數
main() {
    log_info "開始配置Nginx..."
    
    if [[ $# -lt 1 ]]; then
        log_warning "未提供域名，使用默認配置"
        log_info "用法: $0 <domain> [email]"
        log_info "示例: $0 powerautomation.yourdomain.com admin@yourdomain.com"
    fi
    
    create_nginx_config
    enable_site
    test_nginx_config
    setup_ssl
    
    # 重啟Nginx
    sudo systemctl restart nginx
    sudo systemctl enable nginx
    
    log_success "Nginx配置完成！"
    log_info "訪問地址: https://${DOMAIN}"
}

main "$@"

