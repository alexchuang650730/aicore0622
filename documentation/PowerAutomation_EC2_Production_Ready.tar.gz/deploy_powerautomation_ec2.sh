#!/bin/bash

# PowerAutomation EC2 部署腳本
# 用於在Amazon EC2實例上部署PowerAutomation生產級服務

set -e  # 遇到錯誤立即退出

# 顏色定義
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 日誌函數
log_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 檢查是否為root用戶
check_root() {
    if [[ $EUID -eq 0 ]]; then
        log_error "請不要使用root用戶運行此腳本"
        log_info "建議使用ubuntu用戶: sudo -u ubuntu $0"
        exit 1
    fi
}

# 檢查操作系統
check_os() {
    if [[ ! -f /etc/os-release ]]; then
        log_error "無法檢測操作系統"
        exit 1
    fi
    
    . /etc/os-release
    if [[ "$ID" != "ubuntu" ]]; then
        log_error "此腳本僅支持Ubuntu系統"
        exit 1
    fi
    
    log_success "檢測到Ubuntu $VERSION_ID"
}

# 更新系統
update_system() {
    log_info "更新系統包..."
    sudo apt update
    sudo apt upgrade -y
    log_success "系統更新完成"
}

# 安裝基礎依賴
install_dependencies() {
    log_info "安裝基礎依賴..."
    
    sudo apt install -y \
        curl \
        wget \
        git \
        unzip \
        software-properties-common \
        apt-transport-https \
        ca-certificates \
        gnupg \
        lsb-release \
        build-essential \
        python3 \
        python3-pip \
        python3-venv \
        python3-dev \
        nginx \
        supervisor \
        certbot \
        python3-certbot-nginx \
        htop \
        tree \
        jq
    
    log_success "基礎依賴安裝完成"
}

# 安裝Node.js (用於前端構建)
install_nodejs() {
    log_info "安裝Node.js..."
    
    # 安裝NodeSource repository
    curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
    sudo apt-get install -y nodejs
    
    # 驗證安裝
    node_version=$(node --version)
    npm_version=$(npm --version)
    
    log_success "Node.js安裝完成: $node_version"
    log_success "npm版本: $npm_version"
}

# 創建應用目錄
create_app_directory() {
    log_info "創建應用目錄..."
    
    APP_DIR="/home/ubuntu/powerautomation"
    
    if [[ -d "$APP_DIR" ]]; then
        log_warning "應用目錄已存在，備份舊版本..."
        sudo mv "$APP_DIR" "${APP_DIR}_backup_$(date +%Y%m%d_%H%M%S)"
    fi
    
    mkdir -p "$APP_DIR"
    cd "$APP_DIR"
    
    log_success "應用目錄創建完成: $APP_DIR"
}

# 克隆代碼倉庫
clone_repository() {
    log_info "克隆PowerAutomation代碼倉庫..."
    
    cd "$APP_DIR"
    git clone https://github.com/alexchuang650730/aicore0622.git .
    
    # 檢查是否成功克隆
    if [[ ! -d "smartinvention" ]]; then
        log_error "代碼克隆失敗，請檢查網絡連接和倉庫地址"
        exit 1
    fi
    
    log_success "代碼倉庫克隆完成"
}

# 設置Python虛擬環境
setup_python_env() {
    log_info "設置Python虛擬環境..."
    
    cd "$APP_DIR/smartinvention/powerautomation_server"
    
    # 創建虛擬環境
    python3 -m venv venv
    source venv/bin/activate
    
    # 升級pip
    pip install --upgrade pip
    
    # 安裝依賴
    if [[ -f "requirements.txt" ]]; then
        pip install -r requirements.txt
    else
        log_warning "requirements.txt不存在，安裝基礎依賴..."
        pip install flask flask-cors requests
    fi
    
    # 安裝生產級WSGI服務器
    pip install gunicorn
    
    log_success "Python環境設置完成"
}

# 配置環境變量
setup_environment() {
    log_info "配置環境變量..."
    
    ENV_FILE="$APP_DIR/smartinvention/powerautomation_server/.env"
    
    cat > "$ENV_FILE" << EOF
# PowerAutomation 生產環境配置
FLASK_ENV=production
FLASK_DEBUG=False
SECRET_KEY=$(openssl rand -hex 32)

# 服務器配置
HOST=0.0.0.0
PORT=5000
WORKERS=4

# 數據庫配置
DATABASE_URL=sqlite:///database/powerautomation.db

# TRAE配置
TRAE_ENABLED=true
TRAE_TIMEOUT=30

# Manus配置
MANUS_ENABLED=true
MANUS_EMAIL=chuang.hsiaoyen@gmail.com
MANUS_PASSWORD=silentfleet#1234

# 日誌配置
LOG_LEVEL=INFO
LOG_FILE=/var/log/powerautomation/app.log
EOF
    
    # 創建日誌目錄
    sudo mkdir -p /var/log/powerautomation
    sudo chown ubuntu:ubuntu /var/log/powerautomation
    
    log_success "環境變量配置完成"
}

# 測試應用
test_application() {
    log_info "測試應用..."
    
    cd "$APP_DIR/smartinvention/powerautomation_server"
    source venv/bin/activate
    
    # 測試Flask應用導入
    python3 -c "
import sys
sys.path.insert(0, '.')
try:
    from src.main import app
    print('✅ Flask應用導入成功')
    
    with app.test_client() as client:
        response = client.get('/api/powerautomation/health')
        if response.status_code == 200:
            print('✅ 健康檢查通過')
        else:
            print('❌ 健康檢查失敗')
            
except Exception as e:
    print(f'❌ 應用測試失敗: {e}')
    sys.exit(1)
"
    
    if [[ $? -eq 0 ]]; then
        log_success "應用測試通過"
    else
        log_error "應用測試失敗"
        exit 1
    fi
}

# 主函數
main() {
    log_info "開始PowerAutomation EC2部署..."
    
    check_root
    check_os
    update_system
    install_dependencies
    install_nodejs
    create_app_directory
    clone_repository
    setup_python_env
    setup_environment
    test_application
    
    log_success "PowerAutomation基礎部署完成！"
    log_info "接下來請運行以下腳本："
    log_info "  - ./setup_nginx.sh     # 配置Nginx反向代理"
    log_info "  - ./setup_ssl.sh       # 配置SSL證書"
    log_info "  - ./setup_service.sh   # 配置系統服務"
    log_info "  - ./start_service.sh   # 啟動服務"
}

# 執行主函數
main "$@"

