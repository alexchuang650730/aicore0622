#!/bin/bash

# PowerAutomation 系統服務配置腳本
# 創建systemd服務和supervisor配置

set -e

# 顏色定義
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

log_info() { echo -e "${BLUE}[INFO]${NC} $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

APP_DIR="/home/ubuntu/powerautomation"
SERVICE_NAME="powerautomation"

# 創建systemd服務文件
create_systemd_service() {
    log_info "創建systemd服務文件..."
    
    sudo tee /etc/systemd/system/${SERVICE_NAME}.service > /dev/null << EOF
[Unit]
Description=PowerAutomation Flask Application
After=network.target
Wants=network.target

[Service]
Type=notify
User=ubuntu
Group=ubuntu
WorkingDirectory=${APP_DIR}/smartinvention/powerautomation_server
Environment=PATH=${APP_DIR}/smartinvention/powerautomation_server/venv/bin
Environment=FLASK_ENV=production
ExecStart=${APP_DIR}/smartinvention/powerautomation_server/venv/bin/gunicorn --config gunicorn.conf.py src.main:app
ExecReload=/bin/kill -s HUP \$MAINPID
Restart=always
RestartSec=10
KillMode=mixed
TimeoutStopSec=5
PrivateTmp=true
ProtectSystem=strict
ProtectHome=true
ReadWritePaths=${APP_DIR} /var/log/powerautomation /var/run/powerautomation
NoNewPrivileges=true

[Install]
WantedBy=multi-user.target
EOF

    log_success "systemd服務文件創建完成"
}

# 創建supervisor配置
create_supervisor_config() {
    log_info "創建supervisor配置..."
    
    sudo tee /etc/supervisor/conf.d/${SERVICE_NAME}.conf > /dev/null << EOF
[program:${SERVICE_NAME}]
command=${APP_DIR}/smartinvention/powerautomation_server/venv/bin/gunicorn --config gunicorn.conf.py src.main:app
directory=${APP_DIR}/smartinvention/powerautomation_server
user=ubuntu
group=ubuntu
autostart=true
autorestart=true
redirect_stderr=true
stdout_logfile=/var/log/powerautomation/supervisor.log
stdout_logfile_maxbytes=50MB
stdout_logfile_backups=10
environment=FLASK_ENV=production,PYTHONPATH="${APP_DIR}/smartinvention/powerautomation_server"
EOF

    log_success "supervisor配置創建完成"
}

# 創建運行時目錄
create_runtime_dirs() {
    log_info "創建運行時目錄..."
    
    sudo mkdir -p /var/run/powerautomation
    sudo mkdir -p /var/log/powerautomation
    sudo chown ubuntu:ubuntu /var/run/powerautomation
    sudo chown ubuntu:ubuntu /var/log/powerautomation
    
    log_success "運行時目錄創建完成"
}

# 配置日誌輪轉
setup_log_rotation() {
    log_info "配置日誌輪轉..."
    
    sudo tee /etc/logrotate.d/${SERVICE_NAME} > /dev/null << EOF
/var/log/powerautomation/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 ubuntu ubuntu
    postrotate
        systemctl reload ${SERVICE_NAME} > /dev/null 2>&1 || true
    endscript
}
EOF

    log_success "日誌輪轉配置完成"
}

# 設置防火牆規則
setup_firewall() {
    log_info "配置防火牆規則..."
    
    # 檢查ufw是否安裝
    if command -v ufw >/dev/null 2>&1; then
        sudo ufw allow 22/tcp comment 'SSH'
        sudo ufw allow 80/tcp comment 'HTTP'
        sudo ufw allow 443/tcp comment 'HTTPS'
        sudo ufw allow 5000/tcp comment 'PowerAutomation'
        
        # 啟用防火牆（如果尚未啟用）
        sudo ufw --force enable
        
        log_success "防火牆規則配置完成"
    else
        log_warning "ufw未安裝，跳過防火牆配置"
    fi
}

# 主函數
main() {
    log_info "開始配置PowerAutomation系統服務..."
    
    create_runtime_dirs
    create_systemd_service
    create_supervisor_config
    setup_log_rotation
    setup_firewall
    
    # 重新加載systemd
    sudo systemctl daemon-reload
    
    # 重新加載supervisor
    sudo supervisorctl reread
    sudo supervisorctl update
    
    log_success "PowerAutomation系統服務配置完成！"
    log_info "可用的服務管理命令："
    log_info "  systemctl start ${SERVICE_NAME}     # 啟動服務"
    log_info "  systemctl stop ${SERVICE_NAME}      # 停止服務"
    log_info "  systemctl restart ${SERVICE_NAME}   # 重啟服務"
    log_info "  systemctl status ${SERVICE_NAME}    # 查看狀態"
    log_info "  systemctl enable ${SERVICE_NAME}    # 開機自啟"
}

main "$@"

